// Mobile menu toggle
const hamburger = document.querySelector(".hamburger")
const navMenu = document.querySelector(".nav-menu")

hamburger.addEventListener("click", () => {
  hamburger.classList.toggle("active")
  navMenu.classList.toggle("active")
})

// Close mobile menu when clicking on a link
document.querySelectorAll(".nav-link").forEach((n) =>
  n.addEventListener("click", () => {
    hamburger.classList.remove("active")
    navMenu.classList.remove("active")
  }),
)

// Add to cart functionality
document.querySelectorAll(".add-to-cart").forEach((button) => {
  button.addEventListener("click", (e) => {
    const productCard = e.target.closest(".product-card")
    const productName = productCard.querySelector("h4").textContent

    // Simple animation
    button.textContent = "Added!"
    button.style.background = "#28a745"

    setTimeout(() => {
      button.textContent = "Add to Cart"
      button.style.background = "#2c5530"
    }, 2000)

    console.log(`Added to cart: ${productName}`)
  })
})

// Newsletter form submission
document.querySelector(".newsletter-form").addEventListener("submit", (e) => {
  e.preventDefault()
  const email = e.target.querySelector('input[type="email"]').value

  if (email) {
    alert("Thank you for subscribing!")
    e.target.querySelector('input[type="email"]').value = ""
  }
})

// Smooth scrolling for internal links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute("href"))
    if (target) {
      target.scrollIntoView({
        behavior: "smooth",
      })
    }
  })
})

// Health concern items click handler
document.querySelectorAll(".concern-item").forEach((item) => {
  item.addEventListener("click", () => {
    console.log(`Clicked on: ${item.textContent}`)
    // Here you could redirect to a category page or filter products
  })
})

// Brand items click handler
document.querySelectorAll(".brand-item").forEach((item) => {
  item.addEventListener("click", () => {
    console.log(`Clicked on brand: ${item.textContent}`)
    // Here you could redirect to a brand page or filter products
  })
})

// Simple cart counter (you could expand this)
const cartCount = 0

function updateCartCount() {
  // This would update a cart counter in the header if you had one
  console.log(`Cart items: ${cartCount}`)
}

// Add scroll effect to header
window.addEventListener("scroll", () => {
  const header = document.querySelector(".header")
  if (window.scrollY > 100) {
    header.style.background = "rgba(255, 255, 255, 0.95)"
    header.style.backdropFilter = "blur(10px)"
  } else {
    header.style.background = "#fff"
    header.style.backdropFilter = "none"
  }
})
